import argparse

def __args__(parser):
	pass	

def __exec__(args):
	import install

